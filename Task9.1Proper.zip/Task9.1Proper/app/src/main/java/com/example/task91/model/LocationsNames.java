package com.example.task91.model;

public class LocationsNames
{
    private int id;
    private String name;
    private String Latitude;
    private String Longitude;

    public LocationsNames()
    {

    }

    public LocationsNames(String name, String Latitude, String Longitude)
    {
        this.name = name;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
    }

    public LocationsNames(int id, String name, String Latitude, String Longitude)
    {
        this.id = id;
        this.name = name;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getLatitude()
    {
        return Latitude;
    }

    public void setLatitude(String Latitude)
    {

        this.Latitude = Latitude;
    }

    public String getLongitude()
    {
        return Longitude;
    }

    public void setLongitude(String Longitude)
    {
        this.Longitude = Longitude;
    }
}
