package com.example.task91;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{

    Button AddingNewsPlacesButton, ShowingAllPlacesButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AddingNewsPlacesButton = findViewById(R.id.addingNewsPlacesBTN);
        ShowingAllPlacesButton = findViewById(R.id.showingAllsPlacesBTN);

    }

    public void addNewPlace(View view)
    {
        // Start Add New Place Activity
        Intent intent = new Intent(MainActivity.this, AddingNewPlacesActivities.class);
        startActivity(intent);
    }

    public void showAllOnMap(View view)
    {
        // Start Maps Activity
        Intent intent = new Intent(MainActivity.this, MappingsActivities.class);
        startActivity(intent);
    }
}