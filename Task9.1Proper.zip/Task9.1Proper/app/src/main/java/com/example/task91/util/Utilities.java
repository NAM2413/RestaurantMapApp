package com.example.task91.util;

public class Utilities {

    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_NAME = "Location_db";
    public static final String TABLE_NAME = "Locations";

    public static final String LOCATION_ID = "Location_id";
    public static final String LOCATION_NAME = "Name";
    public static final String LATITUDE = "Latitude";
    public static final String LONGITUDE = "Longitude";

    public Utilities() {

    }

}